Rust Map Overlay 1.0 by mf2888 


Description:

Rust Map Overlay is a little programm that lets you display a map over your Rust window. 
You can zoom in and out and navigate through the map. 

Quick Setup:

1. Add a Map to the Folder and change the map name to your added map name in the settings.ini  Example: Map=MyMap.png
2. Start RustMapOverlay.exe  (it is also possible to start Rust Map Overlay when Rust is already running)
3. Start Rust in Window Mode 
4. You can now display your map with M (Default Key)

Closes automaticly when Rust window is closed.
If you want to close it activate the Rust Map Overlay Window and press ESC.


Controls:

Mousewheel Scroll: Zoom in and out
Mousewheel Press: Center your Map
Drag Mouse: Navigate over your Map
ToggleKey: Change between Rust Map Overlay and Rust

Settings:

in settings.ini

Map=map.jpg   			//Path to your Map Image
Transparancy=80			//Transparancy of the window. Values between 20 and 100 allowed
ScrollSpeed=8			//Scrollspeed Values between 1 and 10 allowed
toggleKey=0x4D			//Key Code which toggles the Map (0x4d = M). Look here for key codes 
				  http://msdn.microsoft.com/en-us/library/windows/desktop/dd375731%28v=vs.85%29.aspx
			
				
rustWindowTitle=PlayRust 	//Rust Window Title
showLogo=true			//Show the Rust Map Overlay logo in the upper left corner set it to true or false

Contact:

URL: http://rustmapmarks.com
Email: info@rustmapmarks.com


Rust is Copyright Facepunch Studios and is not affiliated with this programm.


Rust Map Overlay is written in C++ and uses SFML(http://www.sfml-dev.org/) and inih (http://code.google.com/p/inih/) source of Rust Map Overlay included in "source" Folder.


License:

    Rust Map Overlay is a little programm that lets you display a map over your Rust window
    Copyright (C) 2014  Martin Freudenberg

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see http://www.gnu.org/licenses/gpl-3.0