/*
License:

    Rust Map Overlay is a little programm that lets you display a map over your Rust window
    Copyright (C) 2014  Martin Freudenberg
    http://rustmapmarks.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see http://www.gnu.org/licenses/gpl-3.0
*/
#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#define _WIN32_WINNT 0x0501

#include <windows.h>
#include <iostream>
#include "cpp/INIReader.h"
#include <Math.h>


using namespace std;


class RustMapOverlay{

private:

    sf::RenderWindow    *rw;
    sf::WindowHandle    RenderWindowSystemHandle;
    HWND                RustWindow;
    int                 v_keycode;
    bool                displayed;
    bool                locked;
    sf::Clock           locktime;
    int                 Transparancy;
    sf::Sprite          MapSprite;
    sf::Texture         LogoTexture;
    sf::Sprite          LogoSprite;
    std::string         windowTitle;
    float               zoom;
    sf::View            view;
    bool                mousePressed;
    sf::Vector2f        clickpos;
    sf::Vector2i        mousePos;
    float               scrollspeed;

public:

    RustMapOverlay(sf::Texture &maptexture , float scrollspeed, int transparancy, int v_keycode, std::string windowTitle, bool showLogo){

        this->v_keycode = v_keycode;
        this->windowTitle = windowTitle;
        this->scrollspeed = (11 - scrollspeed)/100.f;


        RECT desktop;
        const HWND hDesktop = GetDesktopWindow();
        GetWindowRect(hDesktop, &desktop);
        int horizontal = desktop.right;
        int vertical = desktop.bottom;


        rw = new sf::RenderWindow(sf::VideoMode(horizontal-2, vertical-2), "Rust Map Overlay", sf::Style::None);
        rw->setFramerateLimit(60);
      //  rw->setMouseCursorVisible(false);
        rw->setPosition(sf::Vector2i(1,1));


        RenderWindowSystemHandle = rw->getSystemHandle();
        //Make Window Transparent
        LONG ExtendedStyle = GetWindowLong( RenderWindowSystemHandle,
                                    GWL_EXSTYLE );
        SetWindowLong(  RenderWindowSystemHandle,
               GWL_EXSTYLE,
               ExtendedStyle | WS_EX_LAYERED );

        Transparancy = transparancy;

        displayed = false;
        locked = false;
        toggleScreen(displayed,  RenderWindowSystemHandle);

        if(showLogo){
            LogoTexture.loadFromFile("logo.png");
            LogoSprite.setTexture(LogoTexture);
            //LogoSprite.setPosition(rw->getSize().x-LogoSprite.getGlobalBounds().width - 5, rw->getSize().y -LogoSprite.getGlobalBounds().height - 5 );
            LogoSprite.setPosition(2,2);
        }

        MapSprite.setTexture(maptexture);
        //Scale to Screen Size
        float mapwidth = MapSprite.getGlobalBounds().width;
        float mapheight = MapSprite.getGlobalBounds().height;
        float sx = rw->getSize().x/mapwidth;
        float sy = rw->getSize().y/mapheight;
        //MapSprite.setScale(sx,sy);
        view = sf::View(sf::Vector2f(rw->getSize().x/2, rw->getSize().y/2), sf::Vector2f(rw->getSize().x, rw->getSize().y));


        zoom = 1;
        rw->setView(view);
        draw(*rw);

        mousePressed = false;

    }

    ~RustMapOverlay(){
        delete rw;
    }

private:

    void zoomMap(float offset, float x , float y){

        if((zoom<0.1 && offset < 1) || (zoom>1.5 && offset>1)){

        }
        else{

                zoom*=offset;
                view.zoom(offset);

               sf::Vector2f center = view.getCenter();
               float dx = 0.f;
               float dy = 0.f;
               if(offset < 1){

                    dx =  x - center.x;
                    dy = y - center.y;
               }
               else{

                    dx = rw->getSize().x/2  - center.x;
                    dy = rw->getSize().y/2 - center.y;
               }

               float h = sqrt(dx*dx + dy*dy);
               if(h!=0){
                    dx /= h;
                    dy /= h;
               }
               else{
                    dx = 0;
                    dy = 0;
               }

                view.move(dx*50,dy*50);
                rw->setView(view);
                this->draw(*rw);
        }

    }

    void moveMap(){

          if(mousePressed){
            float dx = sf::Mouse::getPosition(*rw).x - clickpos.x;
            float dy = sf::Mouse::getPosition(*rw).y - clickpos.y;

            float h = sqrt(dx*dx + dy*dy);
            if(h!=0){
                dx/=h;
                dy/=h;
                dx*=(sqrt(zoom)/scrollspeed);
                dy*=(sqrt(zoom)/scrollspeed);
            }
            else if( dx < 10 || dy < 10){
                dx = 0;
                dy= 0;
            }
            else{
                dx = 0;
                dy = 0;
            }


            view.move(-dx,-dy);
            rw->setView(view);
            draw(*rw);

        }

    }

    BYTE getAlpha(double a){

        double fAlpha = a * ( 255.0 /100 );
        return static_cast<BYTE>( fAlpha );

    }

    void toggleScreen(bool d, HWND &h){

        BYTE alpha = 0;
        if(d){
           alpha = getAlpha(Transparancy);
        }

          SetLayeredWindowAttributes(h,
                                0,
                                alpha,
                                0x00000002 );
    }


    void draw(sf::RenderWindow &rw){
        rw.clear();
        rw.draw(MapSprite);


        rw.setView(rw.getDefaultView());
        rw.draw(LogoSprite);
        rw.display();

    }

public:
    void run(){

        if(!lookingforRustWindow()){
            return;
        }

        while (rw->isOpen())
        {
            sf::Event event;
            while (rw->pollEvent(event))
            {
                if (event.type == sf::Event::Closed)
                    rw->close();

               if(event.type == sf::Event::KeyPressed){

                    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Escape)){

                        rw->close();
                    }


                }

                if (event.type == sf::Event::MouseWheelMoved)
                {
                        int d = event.mouseWheel.delta;
                        sf::Vector2i mpos = sf::Mouse::getPosition(*rw);

                        if(d >0){
                            //zoom in

                            zoomMap(0.7,mpos.x,mpos.y);

                        }else if(d<0){
                            //zoom out
                            zoomMap(1.3,mpos.x,mpos.y);
                        }
                }

            }

            if((GetAsyncKeyState(v_keycode) & 0x8000) && !locked)
            {
                 locktime.restart();
                 locked = true;
                 displayed = !displayed;
                 if(!displayed){


                        SwitchToThisWindow(RustWindow,true);
                        SetWindowPos( RustWindow, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE );
                        SetActiveWindow(RustWindow);



                 }else{
                    RustWindow =  FindWindow(0, windowTitle.c_str());
                    if(!RustWindow)return;
                    SetWindowPos( RenderWindowSystemHandle, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE );
                 }
                 toggleScreen(displayed, RenderWindowSystemHandle);


            }


            if(locktime.getElapsedTime().asSeconds()> 0.2){

                locked = false;
            }

            if(sf::Mouse::isButtonPressed(sf::Mouse::Left) && !this->mousePressed ){

                    this->mousePressed = true;
                    clickpos = (sf::Vector2f) sf::Mouse::getPosition(*rw);

            }

            if(!sf::Mouse::isButtonPressed(sf::Mouse::Left)){
                this->mousePressed = false;
            }

            if(sf::Mouse::isButtonPressed(sf::Mouse::Middle)){
                    view.setCenter(rw->getSize().x/2,rw->getSize().y/2);
                    rw->setView(view);
                    draw(*rw);
            }

            if((this->mousePos.x != sf::Mouse::getPosition().x || this->mousePos.y != sf::Mouse::getPosition().y) && displayed){

                moveMap();
            }

            this->mousePos = sf::Mouse::getPosition();

            RustWindow =  FindWindow(0, windowTitle.c_str());
            if(!RustWindow){
                        return;
            }


        }


    }
    //getRustWindow Handle
    bool lookingforRustWindow(){
         std::cout<<"Waiting for "<<windowTitle<<" Window..."<<std::endl;
        while(true){

            this->RustWindow = FindWindow(0, windowTitle.c_str());
            if(this->RustWindow){
                std::cout<<"Window found!"<<std::endl;
                Sleep(100);
                HWND hWnd = GetConsoleWindow();
                ShowWindow( hWnd, SW_MINIMIZE );
                ShowWindow( hWnd, SW_HIDE );
                return true;
            }
            sf::Event event;
            while (rw->pollEvent(event))
            {
                if(event.type == sf::Event::Closed){
                    rw->close();
                    return false;
                }
                if(event.type == sf::Event::KeyPressed){

                    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Escape)){

                        rw->close();
                        return false;
                    }
                }

            }

            Sleep(100);
        }
    }

};



void loadsettings(std::string settingsfile,float &scrollspeed, int &transparancy, int &keycode, std::string &map, std::string &windowTitle , bool &watermark){
    INIReader reader(settingsfile);

    transparancy = reader.GetInteger("SETTINGS","Transparancy", 50);
    if(transparancy < 20) transparancy = 20;
    if(transparancy > 100) transparancy = 100;

    map =  reader.Get("SETTINGS","Map", "Error");
    keycode =  reader.GetInteger("SETTINGS","toggleKey", 0x4D);
    windowTitle = reader.Get("SETTINGS", "rustWindowTitle", "PlayRust");
    watermark = reader.GetBoolean("SETTINGS","showLogo",true);
    scrollspeed = reader.GetInteger("SETTINGS", "ScrollSpeed",7);
    if(scrollspeed<1) scrollspeed = 1;
    if(scrollspeed > 10) scrollspeed = 10;
}



int main()
{
    //load Settings


    int transparancy, v_keycode;
    std::string map, windowTitle;
    bool watermark;
    float scrollspeed;

    loadsettings("settings.ini",scrollspeed ,transparancy,v_keycode, map, windowTitle, watermark);
    sf::Texture t;
    if(!t.loadFromFile(map)){
        MessageBox(NULL,"Map not found! Read the ReadMe.txt on how to add a map.", "Error",MB_ICONERROR);
        return -1;

    }

    RustMapOverlay rustmapoverlay(t, scrollspeed, transparancy , v_keycode, windowTitle, watermark);
    rustmapoverlay.run();

    return 0;

}
